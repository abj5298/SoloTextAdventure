# ta
Text adventure
