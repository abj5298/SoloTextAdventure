public class DogRoom extends EnemyRoom{
    public DogRoom(int x, int y, Enemy enemy) {
        super(x, y, enemy);
    }
    private String[] DR_INTRO = {"A Large three-headed dog"};

    public String intro_text(){
        return DR_INTRO[(int) (java.lang.Math.random() * DR_INTRO.length)];
    }
}
