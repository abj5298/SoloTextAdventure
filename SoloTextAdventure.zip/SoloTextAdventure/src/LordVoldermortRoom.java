public class LordVoldermortRoom extends EnemyRoom{
    public LordVoldermortRoom(int x, int y, Enemy enemy) {
        super(x, y, enemy);
    }
    private String[] LVR_INTRO = {"I have been waiting for you Harry!"};

    public String intro_text(){
        return LVR_INTRO[(int) (java.lang.Math.random() * LVR_INTRO.length)];
    }
}
