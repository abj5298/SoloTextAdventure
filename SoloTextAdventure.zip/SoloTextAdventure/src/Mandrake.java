public class Mandrake extends Weapon {
    public Mandrake(String name, String desc, int value, int damage) {
        super("Mandrake", "An Mandrake. Used to return people who have been transfigured or cursed to their original state.The cry of the Mandrake is fatal to anyone who hears it. ", 20, 30);
    }
}