public class MoveNorth extends Action {
    public MoveNorth() {
        super(Method.MoveNorth, " Move North", 'n', null);
    }
}