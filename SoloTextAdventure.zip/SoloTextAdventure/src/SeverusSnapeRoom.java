public class SeverusSnapeRoom extends EnemyRoom{
    public SeverusSnapeRoom(int x, int y, Enemy enemy) {
        super(x, y, enemy);
    }
    private String[] SSR_INTRO = {"I have been waiting for you Harry!"};

    public String intro_text(){
        return SSR_INTRO[(int) (java.lang.Math.random() * SSR_INTRO.length)];
    }
}

