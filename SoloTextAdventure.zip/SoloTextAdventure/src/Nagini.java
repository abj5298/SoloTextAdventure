public class Nagini extends Enemy{

    private int strength;

    public Nagini(int strength) {

        super( "Nagini", 8, 8);
        this.strength = strength;
    }
}
