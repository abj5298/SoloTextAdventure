public class FindWandRoom extends MapTile{
    public FindWandRoom(int x, int y) {
        super(x, y);
    }
    private final String[] FWR_INTRO = {"You found yourself a wand."};
    public String intro_text(){
        return FWR_INTRO[(int) (java.lang.Math.random() * FWR_INTRO.length)];
    }
}


