public class NaginiRoom extends EnemyRoom{
    public NaginiRoom(int x, int y, Enemy enemy) {
        super(x, y, enemy);
    }
    private String[] NR_INTRO = {"I have been waiting for you Harry!"};

    public String intro_text(){
        return NR_INTRO[(int) (java.lang.Math.random() * NR_INTRO.length)];
    }
}
