public class LordVoldemort extends Enemy{
    private int strength;

    public LordVoldemort(int strength) {

        super("Lord Voldemort", 10, 10);
        this.strength = strength;
    }


    }

