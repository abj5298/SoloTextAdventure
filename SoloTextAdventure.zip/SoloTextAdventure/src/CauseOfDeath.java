public enum CauseOfDeath {
    Nagini, PeterPettigrew, SeverusSnape, LuciusMalfoy, Basilisk, LordVoldemort
}
