import java.util.*;
public class PeterPettigrew extends Enemy {
    public int amicability;
    public boolean Isfriend = false;
    public PeterPettigrew() {
        super("peterpettigrew", 10, 3);
    }
    private void Friend() {
        Enemy peterpettigrew = new PeterPettigrew();
        amicability = (int) (java.lang.Math.random() * 10);
        if (amicability <= 5) {
            Isthreat = true;
            System.out.println("This peterpettigrew does not seem friendly. Best Run! ");
        } else if(amicability > 5){
            System.out.println("You've come across a peterpettigrew. Keep your guard up ");
        }
    }
    public void PeterPettigrewattack(PeterPettigrew peterpettigrew) {
        int reruns = 5;
        while (reruns != 0) {
            Player.hp -= peterpettigrew.damage;
            String[] PeterPettigrewAttack = {"\nYou were just mauled! ", "\nThe peterpettigrew struck you with its claws! ", "\nThat scratch just might bruise ",
                    "\nA sharp bite against your ankles...looks bad "};
            System.out.print(PeterPettigrewAttack[(int) (java.lang.Math.random() * PeterPettigrewAttack.length)]);
            System.out.print("\nYour health is now" + ' ' + Player.hp);
            Enemy PeterPettigrew = null;
            Player.attackEnemy(PeterPettigrew);
            reruns -= 1;
            if (peterpettigrew.hp <= 2){
                Isthreat = false;
                reruns = 0;
                System.out.print("\nThe peterpettigrew ran into a hole in the wall. \nGood riddance.");
            }
            if (peterpettigrew.IsAlive() == true && peterpettigrew.hp > 2 && reruns == 0){
                reruns += 1;
            }
            else if( peterpettigrew.IsAlive() == false && reruns != 0){
                reruns = 0;
            }
        }
    }

    }
