public class Wand extends Weapon {
    public Wand(String name, String desc, int value, int damage) {
        super ( "Wand", "A Wand. Somewhat dangerous ", 10, 20);
    }
}