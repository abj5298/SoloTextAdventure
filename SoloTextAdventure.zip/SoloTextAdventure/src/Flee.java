public class Flee extends Action{
    public Flee(){
        super(Method.Flee, "Flee", 'f', null);
    }
}