public class SwordofGryffindor extends Weapon {
    public SwordofGryffindor() {
        super("Sword of Gryffindor ", "Sword of Gryffindor. The deadliest weapon.", 50, 100);
    }

    {
    }
}
