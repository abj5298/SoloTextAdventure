public class SeverusSnape extends Enemy{

    public SeverusSnape(){
        super( "Severus Snaper", 10, 2);
    }
}
