public class PeterPettigrewRoom extends EnemyRoom{
    public PeterPettigrewRoom(int x, int y, Enemy enemy) {
        super(x, y, enemy);
    }
}
