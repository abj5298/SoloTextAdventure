public class FindSwordofGryffindorRoom extends MapTile{
    public FindSwordofGryffindorRoom(int x, int y) {
        super(x, y);
    }
    private final String[] FSOGR_INTRO = {"You found the sword of Gryffindor. Use it wisely"};
    public String intro_text(){
        return FSOGR_INTRO[(int) (java.lang.Math.random() * FSOGR_INTRO.length)];
    }
    public void modify_player(Player player){

    }
}

