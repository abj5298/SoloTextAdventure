public class FindMandrakeRoom extends MapTile{
    public FindMandrakeRoom(int x, int y) {
        super(x, y);
    }
    private final String[] EMR_INTRO = {"Watch out for Mandrake. The cry of the Mandrake is fatal to anyone who hears it."
    };
    public String intro_text(){
        return EMR_INTRO[(int) (java.lang.Math.random() * EMR_INTRO.length)];
    }
}
