public class MoveSouth extends Action {
    public MoveSouth(){
        super(Method.MoveSouth, "Move South", 's', null);
    }
}
