public class DevilSnare extends Weapon {
    public DevilSnare(String name, String desc, int value, int damage) {
        super ( "DevilSnare", "A DevilSnare. Used its creepers and tendrils to ensnare anyone who touched it, binding their arms and legs and eventually choking them.The harder a person struggled against Devil's Snare, the faster and more tightly it bound them. ", 20, 30);
    }
}