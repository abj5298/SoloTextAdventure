public class Map extends Item{
    public Map() {
        super("Map", "Fragile paper with inky illustrations on it", 3);
    }
}
