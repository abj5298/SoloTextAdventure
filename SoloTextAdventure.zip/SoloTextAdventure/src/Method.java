public enum Method {
    Flee, Attack, Hit, ViewInventory, MoveEast, MoveWest, MoveSouth, MoveNorth
}
