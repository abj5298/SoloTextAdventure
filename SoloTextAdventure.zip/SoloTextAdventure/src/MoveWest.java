public class MoveWest extends Action{
    public MoveWest(){
        super(Method.MoveWest, "Move West", 'w', null);
    }
}
