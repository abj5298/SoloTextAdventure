public class MoveEast extends Action {
    public MoveEast() {
        super(Method.MoveEast, "Move East", 'e', null);
    }
}