public class Hit extends Action{
    public Hit() {
        super(Method.Hit, "Hit", 'k', null);
    }
}
